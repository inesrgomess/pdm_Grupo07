package com.example.mini_app_apc;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {
    private static Retrofit restRetrofit;
    private static Retrofit graphqlRetrofit;

    public static ApiService rest() {
        if (restRetrofit == null) {
            restRetrofit = new Retrofit.Builder()
                    .baseUrl(ApiService.BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return restRetrofit.create(ApiService.class);
    }

    public static GraphQLApi graphql() {
        if (graphqlRetrofit == null) {
            graphqlRetrofit = new Retrofit.Builder()
                    .baseUrl("https://countries.trevorblades.com/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return graphqlRetrofit.create(GraphQLApi.class);
    }
}
