package com.example.mini_app_apc;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {
    String BASE_URL = "http://api.quotable.io/";

    @GET("quotes")
    Call<QuoteResponse> getQuotes(
            @Query("maxLength") int maxLength,
            @Query("limit") int limit
    );
}