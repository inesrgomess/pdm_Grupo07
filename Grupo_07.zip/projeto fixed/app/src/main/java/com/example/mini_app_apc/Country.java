package com.example.mini_app_apc;

public class Country {
    private String name;
    private String capital;
    private String emoji;
    private String currency;

    public Country() {}

    public Country(String name, String capital, String emoji, String currency) {
        this.name = name;
        this.capital = capital;
        this.emoji = emoji;
        this.currency = currency;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCapital() { return capital; }
    public void setCapital(String capital) { this.capital = capital; }

    public String getEmoji() { return emoji; }
    public void setEmoji(String emoji) { this.emoji = emoji; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
}