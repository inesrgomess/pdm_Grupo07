package com.example.mini_app_apc;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class CountryAdapter extends RecyclerView.Adapter<CountryAdapter.CountryViewHolder> {
    private List<Country> countries;

    public CountryAdapter(List<Country> countries) { this.countries = countries; }

    @NonNull @Override
    public CountryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_2, parent, false);
        return new CountryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CountryViewHolder h, int pos) {
        Country c = countries.get(pos);
        String line1 = c.getEmoji() + "  " + c.getName();
        String line2 = "Capital: " + (c.getCapital() == null ? "—" : c.getCapital());
        h.text1.setText(line1);
        h.text2.setText(line2);
    }

    @Override
    public int getItemCount() { return countries != null ? countries.size() : 0; }

    public void updateData(List<Country> newCountries) {
        this.countries = newCountries;
        notifyDataSetChanged();
    }

    static class CountryViewHolder extends RecyclerView.ViewHolder {
        TextView text1, text2;
        CountryViewHolder(@NonNull View itemView) {
            super(itemView);
            text1 = itemView.findViewById(android.R.id.text1);
            text2 = itemView.findViewById(android.R.id.text2);
        }
    }
}
