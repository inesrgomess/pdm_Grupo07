package com.example.mini_app_apc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
    import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GraphQLActivity extends AppCompatActivity {

    private Button btnBack, btnFetchGraphQL;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private TextView txtError;
    private CountryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graphql);

        btnBack = findViewById(R.id.btnBackGraphQL);
        btnFetchGraphQL = findViewById(R.id.btnFetchGraphQL);
        progressBar = findViewById(R.id.progressBarGraphQL);
        recyclerView = findViewById(R.id.recyclerViewPosts);
        txtError = findViewById(R.id.txtError);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CountryAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        btnBack.setOnClickListener(v -> finish());
        btnFetchGraphQL.setOnClickListener(v -> fetchCountries());
    }

    private void fetchCountries() {
        showLoading(true);

        JsonObject body = new JsonObject();
        body.addProperty("query", "query { countries { name capital emoji currency } }");        

        ApiClient.graphql().runQuery(body).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> resp) {
                showLoading(false);
                if (!resp.isSuccessful() || resp.body() == null) {
                    showError("Erro " + resp.code());
                    return;
                }
                try {
                    JsonObject data = resp.body().getAsJsonObject("data");
                    JsonArray arr = data.getAsJsonArray("countries");
                    List<Country> items = new ArrayList<>();
                    for (JsonElement el : arr) {
                        JsonObject obj = el.getAsJsonObject();
                        Country c = new Country(
                                obj.get("name").isJsonNull() ? null : obj.get("name").getAsString(),
                                obj.get("capital").isJsonNull() ? null : obj.get("capital").getAsString(),
                                obj.get("emoji").isJsonNull() ? "" : obj.get("emoji").getAsString(),
                                obj.get("currency").isJsonNull() ? null : obj.get("currency").getAsString()
                        );
                        items.add(c);
                    }
                    showCountries(items);
                } catch (Exception e) {
                    showError("Erro a ler resposta");
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                showLoading(false);
                showError(t.getMessage());
            }
        });
    }

    private void showLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnFetchGraphQL.setEnabled(!loading);
    }

    private void showCountries(List<Country> countries) {
        adapter.updateData(countries);
        recyclerView.setVisibility(View.VISIBLE);
        txtError.setVisibility(View.GONE);
    }

    private void showError(String errorMessage) {
        txtError.setText(errorMessage);
        txtError.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
    }
}
