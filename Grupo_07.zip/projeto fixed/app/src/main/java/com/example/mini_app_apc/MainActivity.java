package com.example.mini_app_apc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnRest, btnGraphQL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnRest = findViewById(R.id.btnRest);
        btnGraphQL = findViewById(R.id.btnGraphQL);

        setupClickListeners();
    }

    private void setupClickListeners() {
        btnRest.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, RestActivity.class));
        });
        btnGraphQL.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, GraphQLActivity.class));
        });
    }
}
