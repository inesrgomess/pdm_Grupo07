package com.example.mini_app_apc;

public class Quote {
    private String _id;
    private String content;
    private String author;
    private String[] tags;
    private int length;

    public String getId() { return _id; }
    public void setId(String _id) { this._id = _id; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String[] getTags() { return tags; }
    public void setTags(String[] tags) { this.tags = tags; }

    public int getLength() { return length; }
    public void setLength(int length) { this.length = length; }
}