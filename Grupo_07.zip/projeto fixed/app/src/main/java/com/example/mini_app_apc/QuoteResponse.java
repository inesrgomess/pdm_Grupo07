package com.example.mini_app_apc;

import java.util.List;

public class QuoteResponse {
    private int count;
    private int totalCount;
    private int page;
    private int totalPages;
    private int lastItemIndex;
    private List<Quote> results;

    public int getCount() { return count; }
    public void setCount(int count) { this.count = count; }

    public int getTotalCount() { return totalCount; }
    public void setTotalCount(int totalCount) { this.totalCount = totalCount; }

    public int getPage() { return page; }
    public void setPage(int page) { this.page = page; }

    public int getTotalPages() { return totalPages; }
    public void setTotalPages(int totalPages) { this.totalPages = totalPages; }

    public int getLastItemIndex() { return lastItemIndex; }
    public void setLastItemIndex(int lastItemIndex) { this.lastItemIndex = lastItemIndex; }

    public List<Quote> getResults() { return results; }
    public void setResults(List<Quote> results) { this.results = results; }
}