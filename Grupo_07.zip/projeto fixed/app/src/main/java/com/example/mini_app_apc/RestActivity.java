package com.example.mini_app_apc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RestActivity extends AppCompatActivity {

    private Button btnBack, btnFetchPosts;
    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private TextView txtError;
    private PostAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rest);

        btnBack = findViewById(R.id.btnBack);
        btnFetchPosts = findViewById(R.id.btnFetchPosts);
        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerViewPosts);
        txtError = findViewById(R.id.txtError);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PostAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        btnBack.setOnClickListener(v -> finish());
        btnFetchPosts.setOnClickListener(v -> fetchQuotesAsPosts());
    }

    private void fetchQuotesAsPosts() {
        showLoading(true);
        ApiClient.rest().getQuotes(120, 10).enqueue(new Callback<QuoteResponse>() {
            @Override
            public void onResponse(Call<QuoteResponse> call, Response<QuoteResponse> resp) {
                showLoading(false);
                if (resp.isSuccessful() && resp.body() != null) {
                    List<Post> posts = new ArrayList<>();
                    for (Quote q : resp.body().getResults()) {
                        Post p = new Post();
                        p.setId(q.getLength());
                        p.setTitle(q.getAuthor());
                        p.setBody(q.getContent());
                        posts.add(p);
                    }
                    showPosts(posts);
                } else {
                    showError("Erro " + resp.code());
                }
            }

            @Override
            public void onFailure(Call<QuoteResponse> call, Throwable t) {
                showLoading(false);
                showError(t.getMessage());
            }
        });
    }

    private void showLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnFetchPosts.setEnabled(!loading);
    }

    private void showPosts(List<Post> posts) {
        adapter.updateData(posts);
        recyclerView.setVisibility(View.VISIBLE);
        txtError.setVisibility(View.GONE);
    }

    private void showError(String errorMessage) {
        txtError.setText(errorMessage);
        txtError.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
    }
}
